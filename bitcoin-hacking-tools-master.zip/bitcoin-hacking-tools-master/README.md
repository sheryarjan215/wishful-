The source code of main tools used in Bitcoin "non-malware-based" attacks.

## Tools list:

# Misc tools

- Double Spender

# Private Key Harvesters

- Electrum cracker

- Brainflayer

- Bruteforce Wallet

- Large Bitcoin Collider Pool Script


# # DISCLAIMER

Do not ask questions about how to configure or use the software.

I'm not responsible for improper use of the code contained in these repositories.
This code has been shared only for security research purpose. 
Do not ask questions about how to configure or use the software.
No support will be provided.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.


Related repositories:
https://github.com/ryancdotorg/brainflayer
https://github.com/glv2/bruteforce-wallet
https://github.com/ankleslapper/Double-Spender/