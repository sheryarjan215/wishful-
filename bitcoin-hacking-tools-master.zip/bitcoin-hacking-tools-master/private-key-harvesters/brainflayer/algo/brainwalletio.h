/*  Copyright (c) 2015 Ryan Castellucci, All Rights Reserved */
#ifndef __BRAINFLAYER_BRAINWALLETIO_H_
#define __BRAINFLAYER_BRAINWALLETIO_H_

int brainwalletio(unsigned char *, size_t, unsigned char *, size_t, unsigned char *);

/* vim: set ts=2 sw=2 et ai si: */
#endif /* __BRAINFLAYER_BRAINWALLETIO_H_ */
